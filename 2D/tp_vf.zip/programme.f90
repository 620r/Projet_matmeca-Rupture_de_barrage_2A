program principal
    
    use mod_maillage
    use mod_precision
    use mod_sortie
    
    implicit none


    !Données initiales
    real(PR) :: T_init
    real(PR) :: clg, cld, clh, clb
    real (PR) :: tmax, cfl, D = 1._PR
    CHARACTER(len=30) :: fichier_maillage
    integer :: nb_mailles, nb_aretes

    !Pour les boucles 
    integer :: i, k, n, nmax, e
    real(PR) :: somme, dt, flux

    !Solution numérique

    real(PR), dimension(:), allocatable :: T 
    real(PR), dimension(:), allocatable :: Tnp1 
    
    !Quantités géométriques

    real(PR), dimension(:), allocatable :: aire_maille
    real(PR), dimension(:), allocatable :: l_arete !la longueur de l’arête 
    real(PR), dimension(:), allocatable :: d_arete !la distance d e utilisée pour le calcul du flux sur l’arête e de numéro k définie ci-dessus
    real(PR), dimension(:,:), allocatable :: coord_noeud !l’abscisse et l’ordonnée
    real(PR), dimension(:,:), allocatable  :: milieu_arete !l’abscisse et l’ordonnée
    
    !Informations de connectivité

    integer, dimension(:,:), allocatable :: arete_maille !les numéros des 3 arêtes du bord de la maille Ω i dans le sens trigonométrique
    integer, dimension(:,:), allocatable :: noeud_maille !les numéros des 3 noeuds du bord de la maille Ω i dans le sens trigonométrique
    integer, dimension(:,:), allocatable :: maille_arete !numéro des deux mailles adjacentes à l’arête n°k.

    !Conditions aux limites

    integer, dimension(:), allocatable :: cl_arete !indique la condition aux limites à appliquer 




    !lecture des données dans un fichier de données 
    open(8,file = "fichier_données.dat")
        read(8,*) T_init
        read(8,*) clg, cld, clh, clb
        read(8,*) tmax
        read(8,*) cfl
        read(8,*) fichier_maillage
    close(8)
    print *, T_init, tmax, cfl, fichier_maillage 

    !lecture du maillage
    call maillage(fichier_maillage, nb_mailles, nb_aretes, coord_noeud, noeud_maille,& 
    aire_maille, l_arete, d_arete, milieu_arete, arete_maille, maille_arete, cl_arete)

    !allocation et initialisation des tableaux pour T et Tnp1
    allocate(T(1:nb_mailles), Tnp1(1:nb_mailles))
    T = T_init
    Tnp1 = T_init

    !Calcul du pas de temps
    dt = 10
    do i = 1, nb_mailles
        somme = 0
        do k = 1, 3
            somme = somme + l_arete(arete_maille(i,k)) *D /d_arete(arete_maille(i,k))

        end do
        dt = min(dt,aire_maille(i)/somme)
    end do
    dt = cfl*dt
    print*, dt

    !Boucle en temps
    nmax = int(tmax/dt)
    call sortie(0, T, coord_noeud, noeud_maille)

    do n = 1, nmax
        do i = 1, nb_mailles
            somme = 0
            do k = 1, 3  
                e =  arete_maille(i,k)   

                if (maille_arete(e,2)==0) then 
                    if (cl_arete(e)==10) then 
                        flux = -D*(clg-T(i))/d_arete(e)
                    elseif (cl_arete(e)==11) then 
                        flux = -D*(cld-T(i))/d_arete(e)
                    elseif (cl_arete(e)==20) then 
                        flux = clh
                    elseif (cl_arete(e)==21) then 
                        flux = clb
                    end if
                else 
                    flux = -D*(T(maille_arete(e,2))-T(i))/d_arete(e) !Pourquoi (e,2) et pas (e,1)
                end if

                somme = somme + flux * l_arete(e)
            end do
            Tnp1(i) = T(i) - dt/aire_maille(i) *somme
        end do
        
        T = Tnp1
        if (mod(n, nmax/10) == 0 .OR. n==1) then
            call sortie(n, T, coord_noeud, noeud_maille)
        end if
    end do 

    
    deallocate(T, Tnp1)

end program principal